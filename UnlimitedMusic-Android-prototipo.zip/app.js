const $=id=>document.getElementById(id);
const audio=$('audio');
let tracks=[],current=-1,view='all',playlists={},activePlaylist='',remoteResults=[],searchTimer;
const JAMENDO_CLIENT_ID='709fa152'; // ID dimostrativo della documentazione: solo test, sostituire prima della pubblicazione.
const saved=JSON.parse(localStorage.getItem('um_state')||'{}');
let favorites=new Set(saved.favorites||[]);playlists=saved.playlists||{};
function persist(){localStorage.setItem('um_state',JSON.stringify({favorites:[...favorites],playlists}));}
function fmt(s){if(!Number.isFinite(s))return'0:00';return Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0')}
function status(msg){$('status').textContent=msg}
function parseFile(file){return {id:(file.name+'_'+file.size+'_'+file.lastModified),name:file.name.replace(/\.[^.]+$/,''),artist:'File dal dispositivo',file,url:URL.createObjectURL(file),source:'local'}}
function addFiles(files){const incoming=[...files].filter(f=>f.type.startsWith('audio/')).map(parseFile);for(const t of incoming)if(!tracks.some(x=>x.id===t.id))tracks.push(t);render();if(incoming.length&&current<0)loadTrack(tracks.length-incoming.length)}
async function searchOnline(query){
 if(!query.trim()){remoteResults=[];render();status('Scrivi il nome di un brano o artista per cercare online.');return}
 status('Ricerca nel catalogo musicale…');
 try{
  const url=new URL('https://api.jamendo.com/v3.0/tracks/');
  url.search=new URLSearchParams({client_id:JAMENDO_CLIENT_ID,format:'json',limit:'25',search:query.trim(),audioformat:'mp31',include:'musicinfo',imagesize:'300',order:'relevance'}).toString();
  const res=await fetch(url); if(!res.ok)throw new Error('Servizio non disponibile ('+res.status+')');
  const data=await res.json();
  if(data.headers && data.headers.status==='failed')throw new Error(data.headers.error_message||'Ricerca non riuscita');
  remoteResults=(data.results||[]).filter(t=>t.audio).map(t=>({id:'jamendo_'+t.id,name:t.name,artist:t.artist_name||'Artista indipendente',url:t.audio,cover:t.album_image||t.image||'',source:'jamendo',sourceUrl:t.shareurl||('https://www.jamendo.com/track/'+t.id),license:t.license_ccurl||''}));
  status(remoteResults.length?`Trovati ${remoteResults.length} brani. La disponibilità può variare in base alla licenza.`:'Nessun brano trovato. Prova un altro termine.');
  render();
 }catch(e){remoteResults=[];render();status('Non riesco a collegarmi al catalogo online. Controlla la connessione e riprova. '+e.message)}
}
function allTracks(){return [...remoteResults,...tracks]}
function loadTrack(i,list=allTracks()){if(!list.length)return;const t=list[(i+list.length)%list.length];current=allTracks().findIndex(x=>x.id===t.id);audio.src=t.url;$('nowTitle').textContent=t.name;$('nowArtist').textContent=t.artist;$('play').textContent='▶';$('nowCover').textContent='♫';if(t.cover){$('nowCover').style.backgroundImage=`url("${t.cover}")`;$('nowCover').style.backgroundSize='cover';$('nowCover').style.backgroundPosition='center'}else{$('nowCover').style.backgroundImage=''}render()}
function toggle(){const list=allTracks();if(current<0){if(list.length)loadTrack(0,list);else{status('Cerca musica online oppure aggiungi file audio dal telefono.');return}}if(audio.paused){audio.play().then(()=>$('play').textContent='Ⅱ').catch(()=>status('Impossibile riprodurre questo brano. Prova un altro risultato.'));}else{audio.pause();$('play').textContent='▶'}}
function render(){
 const q=$('search').value.trim().toLowerCase();let list=allTracks().filter(t=>t.name.toLowerCase().includes(q)||t.artist.toLowerCase().includes(q));
 if(view==='favorites')list=list.filter(t=>favorites.has(t.id));
 if(view==='playlists')list=list.filter(t=>(playlists[activePlaylist]||[]).includes(t.id));
 const c=$('content');c.innerHTML='';
 if(view==='playlists'&&!Object.keys(playlists).length){c.innerHTML='<div class="empty"><h3>Nessuna playlist</h3><p>Crea una playlist e aggiungi brani dai risultati.</p></div>';return}
 if(!list.length){c.innerHTML='<div class="empty"><div class="empty-icon">♫</div><h3>Nessun brano da mostrare</h3><p>Cerca un brano online oppure aggiungi file audio dal telefono.</p><button class="primary" id="emptyAddAgain">＋ Aggiungi brani locali</button></div>';$('emptyAddAgain').onclick=()=>$('filePicker').click();return}
 list.forEach(t=>{
  const row=document.createElement('div');row.className='track';
  const cover=document.createElement('div');cover.className='cover';cover.textContent='♫';if(t.cover){cover.style.backgroundImage=`url("${t.cover}")`;cover.style.backgroundSize='cover';cover.style.backgroundPosition='center'}
  const meta=document.createElement('div');meta.className='meta';const title=document.createElement('b');title.textContent=t.name;const sub=document.createElement('small');sub.textContent=t.artist+(t.source==='jamendo'?' · Jamendo':' · File locale');meta.append(title,sub);
  const fav=document.createElement('button');fav.className=favorites.has(t.id)?'fav':'';fav.setAttribute('aria-label','Preferito');fav.textContent=favorites.has(t.id)?'♥':'♡';fav.onclick=()=>{favorites.has(t.id)?favorites.delete(t.id):favorites.add(t.id);persist();render()};
  const play=document.createElement('button');play.setAttribute('aria-label','Riproduci');play.textContent='▶';play.onclick=()=>{loadTrack(allTracks().findIndex(x=>x.id===t.id));audio.play().then(()=>$('play').textContent='Ⅱ').catch(()=>status('Riproduzione non disponibile per questo brano.'))};
  row.append(cover,meta,fav,play);
  if(t.source==='jamendo'){const source=document.createElement('a');source.className='source-link';source.href=t.sourceUrl;source.target='_blank';source.rel='noopener noreferrer';source.textContent='Apri fonte ↗';source.title='Apri la pagina del brano su Jamendo';row.append(source)}
  if(view==='playlists'){const remove=document.createElement('button');remove.textContent='−';remove.setAttribute('aria-label','Rimuovi dalla playlist');remove.onclick=()=>{playlists[activePlaylist]=(playlists[activePlaylist]||[]).filter(id=>id!==t.id);persist();render()};row.append(remove)}
  else if(Object.keys(playlists).length){const add=document.createElement('button');add.textContent='＋';add.setAttribute('aria-label','Aggiungi a playlist');add.onclick=()=>{const names=Object.keys(playlists);const name=prompt('Aggiungi a quale playlist?\n'+names.join(', '),names[0]);if(name&&playlists[name]){if(!playlists[name].includes(t.id))playlists[name].push(t.id);persist();status('Brano aggiunto a '+name);render()}else if(name)status('Playlist non trovata. Crea prima la playlist nella scheda Playlist.')};row.append(add)}
  c.appendChild(row)
 });
}
$('addFiles').onclick=$('heroAdd').onclick=$('emptyAdd').onclick=()=>$('filePicker').click();
$('filePicker').addEventListener('change',e=>{addFiles(e.target.files);e.target.value=''});
$('play').onclick=toggle;
$('prev').onclick=()=>{const list=allTracks();if(list.length){loadTrack((current<=0?list.length-1:current-1),list);audio.play().then(()=>$('play').textContent='Ⅱ').catch(()=>{})}};
$('next').onclick=()=>{const list=allTracks();if(list.length){loadTrack(current+1,list);audio.play().then(()=>$('play').textContent='Ⅱ').catch(()=>{})}};
audio.addEventListener('timeupdate',()=>{if(audio.duration){$('seek').value=audio.currentTime/audio.duration*1000;$('elapsed').textContent=fmt(audio.currentTime);$('duration').textContent=fmt(audio.duration)}});
$('seek').oninput=()=>{if(audio.duration)audio.currentTime=audio.duration*($('seek').value/1000)};
audio.onplay=()=>$('play').textContent='Ⅱ';audio.onpause=()=>$('play').textContent='▶';
audio.onended=()=>{const list=allTracks();if(list.length){loadTrack(current+1,list);audio.play().catch(()=>{})}};
$('search').addEventListener('input',()=>{render();clearTimeout(searchTimer);const q=$('search').value.trim();if(q.length>=2)searchTimer=setTimeout(()=>searchOnline(q),450);else{remoteResults=[];render();status('Scrivi almeno 2 caratteri per cercare online.')}});
$('searchBtn').onclick=()=>searchOnline($('search').value);
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');view=b.dataset.view;$('playlistTools').hidden=view!=='playlists';render()});
function updatePlaylistSelect(){const s=$('playlistSelect');s.innerHTML='<option value="">Scegli playlist</option>';Object.keys(playlists).forEach(n=>{const o=document.createElement('option');o.value=n;o.textContent=n;s.appendChild(o)})}
$('createPlaylist').onclick=()=>{const n=$('playlistName').value.trim();if(!n)return;if(!playlists[n])playlists[n]=[];activePlaylist=n;$('playlistName').value='';persist();updatePlaylistSelect();$('playlistSelect').value=n;render()};
$('playlistSelect').onchange=e=>{activePlaylist=e.target.value;render()};
updatePlaylistSelect();
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
render();